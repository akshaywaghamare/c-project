#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

int main_exit;
 
 struct student{
 	int id;
 	char age[10];
 	char mob[11];
    char name[50];
    char add[20];
    char massage[20];
 }std,list;
       
       
      
	 
      void main()
{                
 int save;
 int choice;
	  
	
          
           
            system("color 3");
           char d[25]="Password Protected ";
           char ch,pass[20],password[20]="lakhan";
           int i=0,j;


           for(j=0;j<6;j++)
           {
           Sleep(20);
           printf("\3");
           }
           for(j=0;j<9;j++)
            {
            Sleep(20);
			
            printf("%c",d[j]);
           }
        
		  for(j=0;j<6;j++)
            {
           Sleep(20);
           printf("\3");
           }

             printf("\nEnter Password:\n");

            while(ch!=13)
            {
              ch=getch();

             if(ch!=13 && ch!=8)
			 {
             putch('\5');
             pass[i] = ch;
            i++;
          }
         }
        
             pass[i] = '\0';
           if(strcmp(pass,password)==0)
      
                 {



             printf("Password match\n");

            printf("Press any key to countinue.....");
            
            system("cls");
     while(1)
          {
	  
	  
	  system("color 30");
	  
	   printf(" \n\n\t\t\t\t\t\t\t\  student information table  ");
	  printf(" \n\n\t\t\t\t\t\t\t\xB2\xB2\6  welcome to the main menu   \6\xB2\xB2\ ");
	  
	  printf(" \n\n\n\t\t\t\t\t\t\t\ 1.add student ");
	  
	  
	  printf("\n\t\t\t\t\t\t\t\ 2.view list");
	  
	  
	  printf("\n\t\t\t\t\t\t\t\ 3. search student");
	  
	  
	  printf("\n\t\t\t\t\t\t\t\ 4. delete");
	  
	  printf("\n\t\t\t\t\t\t\t\ 5. update student information");
	  
	  
	  printf("\n\t\t\t\t\t\t\t\ 6. exit");
	  
	  printf("\n\n\n\n\t\t\t\t\t\t\t\ enter choice");
	  scanf("%d",&choice);
	  system("cls");
	  
	   switch(choice)
	  
	   {
	   	
	   	 case 1:
	   	 {
			
	   	 		FILE *ptr;

                ptr=fopen("data.dat","a+");
	   	 		 system("cls");
	   	 		printf("\t\t\t\xB2\xB2\3  Add record   \3\xB2\xB2\ ");
				printf("\n\t\t\t\ enter a id");
	   	 		scanf("%d",&std.id);
	   	 		
	   	 		printf("\n\t\t\t\ enter a name ");
	   	 		scanf("%s",&std.name);
	   	 		
	   	 		printf(" \n\t\t\t\ enter a massage ");
	   	 		scanf("%s",&std.massage);
	   	 		
	   	 		printf(" \n\t\t\t\ enter a address");
	   	 		scanf("%s",&std.add);
	   	 		
	   	 		printf(" \n\t\t\t\ enter a mobile number ");
	   	 		scanf("%s",&std.mob);
	   	 		
	   	 		printf(" \n\t\t\t\ enter a age ");
	   	 		scanf("%s",&std.age);
	   	 		
	   	 		fprintf(ptr,"%d %s %s %s %s %s \n", std.id,std.name,std.massage,std.add,std.mob,std.age);
	   	 		fclose(ptr);
	   	 		
	   	 		printf(" \n\t\t\t\ record succesfully saved ");
	   	 		printf(" \n\t\t\t\ enter 1 to go to main menu ");
	   	 		scanf("%e",&save);
	   	 		
	   	 	    system("cls");
	   	 		
	   	 		
	   	 		
	   	 		
	   	 		break;
	   	 }
	   	 case 2:
					
					{
						FILE *view;
                        
                     
                         
                        
                        view=fopen("data.dat","r");
                        int test=1;
						  system("cls");
						printf("\n id.no\t name\t massage\t add\t\tmob\t\tage \n");
					
					    while(fscanf(view," %d %s %s %s %s %s",&std.id,&std.name,&std.massage,&std.add,&std.mob,&std.age)>=test)
						{
							printf("\n   %d \t%s \t %s \t\t%s\t   %s\t\t%s",std.id,std.name,std.massage,std.add,std.mob,std.age);
							test++;
							}					    
					    
					    fclose(view);
					    
	   	 		        printf("\n\t\t\t\ enter 1 to go to main menu");
	   	 		        scanf("%e");
					    system("cls");
					   break;
					   
					}
					
					 case 3:
					 	{
					 	 FILE *ptr;
                    int test=1;
                    int save;
                    int choice;
                    ptr=fopen("data.dat","r");
                    printf("\nDo you want to check record \n\nEnter 1 to check record:");
                    scanf("%d",&choice);
                    if (choice==1)
                {   printf("Enter the  ID :");
                    scanf("%d",&list.id);

                    while (fscanf(ptr,"%d %s %s %s %s %s ",&std.id,&std.name,&std.massage,&std.add,&std.mob,&std.age) !=EOF)
                 {
                      if(std.id==list.id)
                    {   
			            system("cls");
                
			              printf("\n   %d \t %s \t %s  \t%s  \t%s \t%s",std.id,std.name,std.massage,std.add,std.mob,std.age);  
			
			      
        	            printf("\n");
					printf("Press 1 Goto Main Menu... \n");
					
					scanf("%d",&save);
					
					system("cls");
                  fclose(ptr);
	   }
      }
	}
    
     

                    else
     
                   {
     	
     	             printf("\n\n Warning!! Incorrect Choice");

			           printf(" \n\n Please press 'Enetr' key....\n");
			        getch();
			          main();
			
	 }

             }
					
						 
						 
						 case 4:
						 	{
						 		
						 		
						 		
						 		{
						
						   FILE *old,*newrec;
                           
                           old=fopen("data.dat","r");
                            newrec=fopen("new.dat","w");
                           printf("Enter the id. of the customer you want to delete:");
                           scanf("%d",&list.id);
                            while (fscanf(old,"%d %s %s %s %s %s",&std.id,&std.name,&std.massage,&std.add,&std.mob,&std.age)!=EOF)
                          {
                            if(std.id!=list.id)
                                fprintf(newrec,"%d %s %s %s %s %s\n",std.id,std.name,std.massage,std.add,std.mob,std.age);

                               else
                               { 
                                    printf("\nRecord deleted successfully!\n");
                                 }
                            }
                                  fclose(old);
                                     fclose(newrec);
                                    remove("data.dat");
                                    rename("new.dat","data.dat");
                   
    
                                    system("cls");
					            break;
						
							
						
						
						
						 		
						 		
							 }
							 
							 case 5:
							 	{
							 		
                                int choice,test=0;
                                 FILE *old,*newrec;
                                old=fopen("data.dat","r");
                                newrec=fopen("new.dat","w");

                                printf("\nEnter the id you want to change:");
                                scanf("%d",&list.id);
                                while(fscanf(old,"%d %s %s %s %s %s",&std.id,&std.name,&std.massage,&std.add,&std.mob,&std.age)!=EOF)
                            {
                                if (std.id==list.id)
                                {   test=1;
                                     printf("\nWhich information do you want to change?\n1.name\n2.massage\n3.Address\n4.mobilr number\n6.Age\n\nEnter your choice:");
                                     scanf("%d",&choice);
                                    system("cls");
                                if(choice==1)
                                   {printf("Enter the new name:");
                                    scanf("%s",std.name);
                
                                    printf("Enter the new massage:");
                                    scanf("%s",std.massage);
                
                                    printf("Enter the new address:");
                                    scanf("%s",&std.add);
                  
                                    printf("Enter the new mobile number:");
                                    scanf("%s",std.mob);
                
                                    printf("Enter the age:");
                                    scanf("%s",std.age);
                                    fprintf(newrec,"\n   %d \t%s \t %s \t\t%s\t   %s\t\t%s",std.id,std.name,std.massage,std.add,std.mob,std.age);
                
                                    printf("Changes saved!");
                                 }
            

                           }
                             else
                                    fprintf(newrec,"%d %s %s %s %s %s\n",std.id,std.name,std.massage,std.add,std.mob,std.age);
                             }
                              fclose(old);
                              fclose(newrec);
                              remove("data.dat");
                              rename("new.dat","data.dat");
                              
                              
                            printf("Record not found \n Press 1 Goto Main Menu... ");
					
					        scanf("%d",&save);
					      
           
                              system("cls");
                              break;
        }
   
        
				
					default :
					 		break;
		}
	}
					 	
	}


	    }

	
                else
        {
		  

             printf("\aWarning!! Incorrect Password");
             getch();
            system("cls");
           main();
            	}  
   

}


   
   
   
